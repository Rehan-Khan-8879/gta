function loadXML() {
  let xhttp = new XMLHttpRequest();

  xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {

      let xml = this.responseXML;
      let products = xml.getElementsByTagName("product");

      let output = "<table border='1' cellpadding='10'>";
      output += "<tr><th>Name</th><th>Price</th></tr>";

      for (let i = 0; i < products.length; i++) {
        let name = products[i].getElementsByTagName("name")[0].childNodes[0].nodeValue;
        let price = products[i].getElementsByTagName("price")[0].childNodes[0].nodeValue;

        output += "<tr>";
        output += "<td>" + name + "</td>";
        output += "<td>₹" + price + "</td>";
        output += "</tr>";
      }

      output += "</table>";

      document.getElementById("data").innerHTML = output;
    }
  };

  xhttp.open("GET", "data.xml", true);
  xhttp.send();
}