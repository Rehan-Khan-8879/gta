<?php
$conn = new mysqli("localhost","root","","test");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $email = $_POST['email'];

    $sql = "INSERT INTO users (name,email) VALUES ('$name','$email')";
    $conn->query($sql);

    echo "Registered Successfully";
}
?>

<form method="post">
<input name="name" placeholder="Name"><br><br>
<input name="email" placeholder="Email"><br><br>
<button type="submit">Register</button>
</form>