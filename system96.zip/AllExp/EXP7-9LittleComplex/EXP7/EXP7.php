<?php
session_start();
$user = "admin";
$pass = "1234";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if ($_POST['username'] == $user && $_POST['password'] == $pass) {
        $_SESSION['user'] = $user;
        echo "Login Success";
    } else {
        echo "Login Failed";
    }
}
?>

<form method="POST">
  Username: <input type="text" name="username"><br><br>
  Password: <input type="password" name="password"><br><br>
  <button type="submit">Login</button>
</form>