ORG 0000H
	MOV Tmod, #01h
	here:
		MOV TH0, #0FEh
		MOV TL0,#34h
		cpl P1.0
		ACALL delay
		SJMP here
		
		
		delay:
			setb TR0
			again:
				JNB TF0, again
				CLR TR0
				CLR TF0
				Ret
END