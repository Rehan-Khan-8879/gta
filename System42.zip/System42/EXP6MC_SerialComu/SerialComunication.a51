ORG 0000H
LJMP START

ORG 0050H
STRING: 
    DB 'REHAN KHAN',00H  ;ya naam change karo apne hisaaab or practical se

START:
    MOV TMOD, #20H      ; Timer1 Mode2
    MOV TH1, #0FDH      ; 9600 baud rate
    MOV SCON, #50H      ; Serial mode1

    SETB TR1            ; Start Timer1
    MOV DPTR, #STRING   ; Point to string

SEND:
    CLR A
    MOVC A, @A+DPTR     ; Read character

    JZ STOP             ; If 00H ? stop

    MOV SBUF, A         ; Send character

WAIT:
    JNB TI, WAIT        ; Wait till sent
    CLR TI

    INC DPTR            ; Next character
    SJMP SEND

STOP:
    SJMP STOP           ; Infinite loop

END