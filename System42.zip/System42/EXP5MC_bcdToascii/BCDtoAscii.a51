ORG 0000H

MOV A, #45H        ; Load BCD number

MOV 20H, A         ; Save original BCD

; -------- Upper digit --------
ANL A, #0F0H       ; Mask upper nibble
SWAP A             ; Bring upper digit to lower nibble
ADD A, #30H        ; Convert to ASCII
MOV 30H, A         ; Store ASCII of upper digit

; -------- Lower digit --------
MOV A, 20H         ; Get original BCD
ANL A, #0FH        ; Mask lower nibble
ADD A, #30H        ; Convert to ASCII
MOV 31H, A         ; Store ASCII of lower digit

HERE: SJMP HERE    ; Infinite loop (important in Keil)

END