ORG 0000H

;-----------------------------
; ADDITION (Immediate + Register)
;-----------------------------
MOV A, #05H        ; Immediate addressing
MOV R0, #04H       ; Register addressing
ADD A, R0          ; A = 25H + 15H = 3AH
MOV 30H, A         ; Store result in RAM (Direct addressing)

;-----------------------------
; SUBTRACTION (Register)
;-----------------------------
MOV A, #08H
MOV R1, #02H
CLR C              ; Clear carry for subtraction
SUBB A, R1         ; A = 50H - 20H = 30H
MOV 31H, A         ; Store result

;-----------------------------
; MULTIPLICATION (Register)
;-----------------------------
MOV A, #02H
MOV B, #04H
MUL AB             ; A = Low byte, B = High byte
MOV 32H, A         ; Store low byte
MOV 33H, B         ; Store high byte

;-----------------------------
; DIVISION (Register)
;-----------------------------
MOV A, #20H
MOV B, #04H
DIV AB             ; A = Quotient, B = Remainder
MOV 34H, A         ; Store quotient
MOV 35H, B         ; Store remainder

;-----------------------------
; END PROGRAM
;-----------------------------
HERE: SJMP HERE

END