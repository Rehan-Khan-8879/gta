ORG 0000H

;-----------------------------
; STORE VALUES IN SOURCE (30H�34H)
;-----------------------------
MOV 30H, #11H
MOV 31H, #22H
MOV 32H, #33H
MOV 33H, #44H
MOV 34H, #55H

;-----------------------------
; BLOCK TRANSFER (30H ? 40H)
;-----------------------------
MOV R0, #30H     ; Source
MOV R1, #40H     ; Destination
MOV R2, #05H     ; Count = 5

LOOP:
    MOV A, @R0
    MOV @R1, A

    INC R0
    INC R1

    DJNZ R2, LOOP

;-----------------------------
; END
;-----------------------------
HERE: SJMP HERE

END