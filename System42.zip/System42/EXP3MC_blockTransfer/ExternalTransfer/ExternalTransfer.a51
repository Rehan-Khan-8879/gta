ORG 000H
	
	MOV 40H, #01H
	MOV 41H, #02H
	MOV 42H, #03H
	MOV 43H, #04H
	MOV 44H, #05H
	
	MOV r0, #40H
	MOV dptr,#2000H
	MOV r7, #05H
	
	rpt:
	MOV A, @R0
	MOVX @dptr, A
	
	INC R0
	INC DPTR
	
	DJNZ R7, rpt
	end
		
		
		;press ctrl f7   the press f7 then press cntrl f5 then run the program form just f5